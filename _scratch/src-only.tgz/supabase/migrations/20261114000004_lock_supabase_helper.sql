-- Supabase's "automatic RLS" setting creates public.rls_auto_enable() (SECURITY DEFINER).
-- It only needs to run as an event trigger; nobody should call it through the API.
do $$
begin
  if exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
             where n.nspname = 'public' and p.proname = 'rls_auto_enable') then
    revoke execute on function public.rls_auto_enable() from public, anon, authenticated;
  end if;
end $$;
